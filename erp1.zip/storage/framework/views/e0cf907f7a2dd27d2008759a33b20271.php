<!-- jquery
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
    <!-- bootstrap JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <!-- wow JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
    <!-- price-slider JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/jquery-price-slider.js')); ?>"></script>
    <!-- meanmenu JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/jquery.meanmenu.js')); ?>"></script>
    <!-- owl.carousel JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <!-- sticky JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/jquery.sticky.js')); ?>"></script>
    <!-- scrollUp JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/jquery.scrollUp.min.js')); ?>"></script>
    <!-- mCustomScrollbar JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/scrollbar/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scrollbar/mCustomScrollbar-active.js')); ?>"></script>
    <!-- metisMenu JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/metisMenu/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/metisMenu/metisMenu-active.js')); ?>"></script>
    <!-- morrisjs JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/sparkline/jquery.sparkline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sparkline/jquery.charts-sparkline.js')); ?>"></script>
    <!-- calendar JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/calendar/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/calendar/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/calendar/fullcalendar-active.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/data-table/bootstrap-table.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/tableExport.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/data-table-active.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/bootstrap-table-editable.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/bootstrap-editable.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/bootstrap-table-resizable.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/colResizable-1.5.source.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/bootstrap-table-export.js')); ?>"></script>
    <!--  editable JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/editable/jquery.mockjax.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/mock-active.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/select2.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/bootstrap-datetimepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/bootstrap-editable.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/xediable-active.js')); ?>"></script>


    <!-- maskedinput JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/jquery.maskedinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/masking-active.js')); ?>"></script>
    <!-- datepicker JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/datepicker/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datepicker/datepicker-active.js')); ?>"></script>
    <!-- form validate JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/form-validation/jquery.form.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/form-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/form-validation/form-active.js')); ?>"></script>
    <!-- dropzone JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/dropzone/dropzone.js')); ?>"></script>
    <!-- tab JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/tab.js')); ?>"></script>
    <!-- plugins JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
    <!-- main JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <!-- tawk chat JS
        ============================================ -->
    <!-- <script src="<?php echo e(asset('assets/js/tawk-chat.js')); ?>"></script> -->

    <script>
    <?php if(Session::has('success')): ?>
    toastr.success("<?php echo e(Session::get('success')); ?>", 'Success!')
    <?php endif; ?>

    <?php if(Session::has('warning')): ?>
    toastr.warning("<?php echo e(Session::get('warning')); ?>", 'Warning!')
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
    toastr.error("<?php echo e(Session::get('error')); ?>", 'Error!')
    <?php endif; ?>
<?php if((request()->routeIs('siteengineer.material_order.create')) or (request()->routeIs('siteengineer.material_order.edit'))): ?>

    $(document).ready(function(){
        $('.add_item').on('click',function(e){
            e.preventDefault();

            var rowd='<tr><td><select name="meterial_id[]" class="form-control"><option value="">Select Material</option><?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($material->id); ?>"><?php echo e($material->meterial_name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td><td><input class="form-control" name="quantity[]" type="number" min="0"></td><td><button class="btn btn-danger remove_item">Remove</button></td></tr>';
                
            $(".show_item").append(rowd);
        });
        $("body").on("click",".remove_item",function(){
          
            $(this).closest("tr").remove();
            
          
        });

    });
    <?php endif; ?>
    <?php if((request()->routeIs('siteengineer.workerentry.create'))or(request()->routeIs('siteengineer.workerentry.edit'))): ?>

    $(document).ready(function(){
        $('.add_item').on('click',function(e){
            e.preventDefault();

            var rowd='<tr><td><select name="worker_type[]" class="form-control"><option value="">Select Worker Type</option><?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($worker->name); ?>"><?php echo e($worker->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></td><td><input class="form-control" name="count[]" type="number" min="0"></td><td><button class="btn btn-danger remove_item">Remove</button></td></tr>';
                
            $(".show_item").append(rowd);
        });
        $("body").on("click",".remove_item",function(){
          
            $(this).closest("tr").remove();
            
          
        });
        $('#site_id').on('change', function () {
            var siteId = $(this).val();
            if (siteId) {
                // Make an AJAX request to fetch the payment data
                $.ajax({
                    url: '/site_engineer/payments/' + siteId,
                    type: 'GET',
                    dataType: 'json',
                    success: function (data) {
                        if (data.mesthiri_id != null) {
                            console.log(data);
                            
                            $('#mesthiri_id').val(data.mesthiri_id);
                            // If payment data exists, fill the input fields
                            
                        }
                        else
                        {
                            alert('Mesthiri not Assigned for this site');
                        }
                    },
                    error: function () {
                        // Handle error if the AJAX request fails
                    }
                });
            }
        });
    });
    <?php endif; ?>
<?php if(request()->routeIs('account.site_payment.create')): ?>
    // Assuming you're using jQuery for simplicity
    $(document).ready(function () {
        $('#site_id').on('change', function () {
            var siteId = $(this).val();
            if (siteId) {
                // Make an AJAX request to fetch the payment data
                $.ajax({
                    url: '/account/payments/' + siteId,
                    type: 'GET',
                    dataType: 'json',
                    success: function (data) {
                        if (data) {
                            if (data && Object.keys(data).length > 0)
                            {
                                $('#total').val(data.amount);
                                $('#paid').val(data.paid);
                                $('#oldpaid').val(data.paid);
                                $('#pending').val(data.pending);
                                
                            }
                            else
                            {
                                $('#total').val(0);
                                $('#paid').val(0);
                                $('#oldpaid').val(0);
                                $('#pending').val(0);
                            }
                            // If payment data exists, fill the input fields
                            
                        }
                    },
                    error: function () {
                        // Handle error if the AJAX request fails
                    }
                });
            }
        });
        $('#amount').on('input', function () {
            var amount = Number($(this).val());
            var total = Number($('#total').val());
            var paid = Number($('#paid').val());
            var oldpaid = Number($('#oldpaid').val());
            var currentpay = (oldpaid + amount);
            var pay = (total - currentpay);
            $('#paid').val(currentpay);
            $('#pending').val(pay);
        });
    });

<?php endif; ?>
<?php if(request()->routeIs('account.material_payment.create')): ?>
    // Assuming you're using jQuery for simplicity
    $(document).ready(function () {
        $('#materialins_id').on('change', function () {
            var orderid = $(this).val();
            if (orderid) {
                // Make an AJAX request to fetch the payment data
                $.ajax({
                    url: '/account/pay/' + orderid,
                    type: 'GET',
                    dataType: 'json',
                    success: function (data) {
                        if (data) {
                            if (data && Object.keys(data).length > 0)
                            {
                                $('#total').val(data.amount);
                                $('#paid').val(data.paid);
                                $('#oldpaid').val(data.paid);
                                $('#pending').val(data.pending);
                                
                            }
                            else
                            {
                                $('#total').val(0);
                                $('#paid').val(0);
                                $('#oldpaid').val(0);
                                $('#pending').val(0);
                            }
                            // If payment data exists, fill the input fields
                            
                        }
                    },
                    error: function () {
                        // Handle error if the AJAX request fails
                    }
                });
            }
        });
        $('#amount').on('input', function () {
            var amount = Number($(this).val());
            var total = Number($('#total').val());
            var paid = Number($('#paid').val());
            var oldpaid = Number($('#oldpaid').val());
            var currentpay = (oldpaid + amount);
            var pay = (total - currentpay);
            $('#paid').val(currentpay);
            $('#pending').val(pay);
        });
    });

<?php endif; ?>
<?php if(request()->routeIs('account.land_payment.create')): ?>
    // Assuming you're using jQuery for simplicity
    $(document).ready(function () {
        $('#landcustomers_id').on('change', function () {
            var orderid = $(this).val();
            if (orderid) {
                // Make an AJAX request to fetch the payment data
                $.ajax({
                    url: '/account/landpay/' + orderid,
                    type: 'GET',
                    dataType: 'json',
                    success: function (data) {
                        if (data) {
                            if (data && Object.keys(data).length > 0)
                            {
                                $('#total').val(data.amount);
                                $('#paid').val(data.paid);
                                $('#oldpaid').val(data.paid);
                                $('#pending').val(data.pending);
                                
                            }
                            else
                            {
                                $('#total').val(0);
                                $('#paid').val(0);
                                $('#oldpaid').val(0);
                                $('#pending').val(0);
                            }
                            // If payment data exists, fill the input fields
                            
                        }
                    },
                    error: function () {
                        // Handle error if the AJAX request fails
                    }
                });
            }
        });
        $('#amount').on('input', function () {
            var amount = Number($(this).val());
            var total = Number($('#total').val());
            var paid = Number($('#paid').val());
            var oldpaid = Number($('#oldpaid').val());
            var currentpay = (oldpaid + amount);
            var pay = (total - currentpay);
            $('#paid').val(currentpay);
            $('#pending').val(pay);
        });
    });

<?php endif; ?>
    // toast config
    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "hideMethod": "fadeOut"
    }

    

</script><?php /**PATH C:\xampp\htdocs\erp1\resources\views/layouts/parts/script.blade.php ENDPATH**/ ?>
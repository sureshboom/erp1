<li >
    <a  href="<?php echo e(route('salesmanager.allcustomers')); ?>">
       <span class="educate-icon educate-professor icon-wrap"></span>
       <span class="mini-click-non">Customer</span>
    </a>
</li>
<li >
    <a  href="<?php echo e(route('salesmanager.teleworks')); ?>">
       <span class="educate-icon educate-data-table icon-wrap"></span>
       <span class="mini-click-non">Telecaller's Work</span>
    </a>
</li>
<li >
    <a  href="<?php echo e(route('salesmanager.siteview')); ?>">
       <span class="educate-icon educate-data-table icon-wrap"></span>
       <span class="mini-click-non">Site Visit</span>
    </a>
</li>
<li>
   <a class="has-arrow" href="#">
       <span class="educate-icon educate-library icon-wrap"></span>
       <span class="mini-click-non">Reports</span>
    </a>
</li>
<?php /**PATH C:\xampp\htdocs\erp1\resources\views/components/user/salesmanager/sidebar.blade.php ENDPATH**/ ?>
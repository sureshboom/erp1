<?php echo $__env->make('layouts.parts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Start Welcome area -->
<div class="all-content-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="logo-pro " >
                    <a href="#."><img style="max-height: 50px;" class="main-logo" src="<?php echo e(asset('image/skslogo.png')); ?>" alt="" /></a>
                </div>
            </div>
        </div>
    </div>
    <div class="header-advance-area">
        <div class="header-top-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="header-top-wraper">
                            <div class="row">
                                <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                    <div class="menu-switcher-pro">
                                        <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
                                                <i class="educate-icon educate-nav"></i>
                                            </button>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                    <div class="header-top-menu tabl-d-n">
                                        
                                    </div>
                                </div>
                                <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                    <div class="header-right-info">
                                        <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                            
                                            <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="educate-icon educate-bell" aria-hidden="true"></i><span class="indicator-nt"></span></a>
                                                <div role="menu" class="notification-author dropdown-menu animated zoomIn">
                                                    <div class="notification-single-top">
                                                        <h1>Notifications</h1>
                                                    </div>
                                                    <ul class="notification-menu">
                                                        
                                                    </ul>
                                                    <div class="notification-view">
                                                        <a href="#">View All Notification</a>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                                    <?php $user = Auth::user(); ?>
                                                        <img src="<?php echo e($user->account ? $user->account->photo : ($user->siteengineer ? $user->siteengineer->photo : ($user->telecaller ? $user->telecaller->photo : ($user->chiefengineer ? $user->chiefengineer->photo : ($user->salesmanager ? $user->salesmanager->photo : ($user->salesperson ? $user->salesperson->photo : '')))))); ?>" alt="" style="width:35px;" />
                                                        <span class="admin-name"><?php echo e(Auth::user()->name); ?>  </span>
                                                        <i class="fa fa-angle-down edu-icon edu-down-arrow"></i>
                                                    </a>
                                                <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated zoomIn">
                                                    
                                                    <li><a href="#"><span class="edu-icon edu-user-rounded author-log-ic"></span>My Profile</a>
                                                    </li>
                                                    
                                                    <li>
                                                        <a  href="<?php echo e(route('admin.logout')); ?>"
                                                       onclick="event.preventDefault();
                                                                     document.getElementById('logout-form').submit();">
                                                                     <i class="fa fa-sign-out"></i>
                                                        <span><?php echo e(__('Logout')); ?></span>
                                                    </a>

                                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                        <?php echo csrf_field(); ?>
                                                    </form>
                                                    </li>

                                                </ul>
                                            </li>
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Mobile Menu start -->
        <div class="mobile-menu-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="mobile-menu">
                            <nav id="dropdown">
                            <ul class="mobile-menu-nav">
                                <li><a  href="<?php echo e(route('user.dashboard')); ?>">Dashboard <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
                                        
                                </li>
                                <?php if(auth()->guard('user')->check()): ?>
                                    <?php if(auth()->user()->role == 'telecaller'): ?>
                                        <?php if (isset($component)) { $__componentOriginal1985022eee24ade8809405ca9f8e5ca6 = $component; } ?>
<?php $component = App\View\Components\User\Telecaller\Mobilebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.telecaller.mobilebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Telecaller\Mobilebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1985022eee24ade8809405ca9f8e5ca6)): ?>
<?php $component = $__componentOriginal1985022eee24ade8809405ca9f8e5ca6; ?>
<?php unset($__componentOriginal1985022eee24ade8809405ca9f8e5ca6); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->role == 'account'): ?>
                                        <?php if (isset($component)) { $__componentOriginal1d16a9126bb29b6d1ee265424d00ee57 = $component; } ?>
<?php $component = App\View\Components\User\Account\Mobilebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.account.mobilebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Account\Mobilebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1d16a9126bb29b6d1ee265424d00ee57)): ?>
<?php $component = $__componentOriginal1d16a9126bb29b6d1ee265424d00ee57; ?>
<?php unset($__componentOriginal1d16a9126bb29b6d1ee265424d00ee57); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->role == 'siteengineer'): ?>
                                        <?php if (isset($component)) { $__componentOriginal4d858142498f6f015ebd381a94f2a394 = $component; } ?>
<?php $component = App\View\Components\User\Siteengineer\Mobilebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.siteengineer.mobilebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Siteengineer\Mobilebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d858142498f6f015ebd381a94f2a394)): ?>
<?php $component = $__componentOriginal4d858142498f6f015ebd381a94f2a394; ?>
<?php unset($__componentOriginal4d858142498f6f015ebd381a94f2a394); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->role == 'chiefengineer'): ?>
                                        <?php if (isset($component)) { $__componentOriginal80de0ebd7d076cd9511551113cf7ca55 = $component; } ?>
<?php $component = App\View\Components\User\Chiefengineer\Mobilebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.chiefengineer.mobilebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Chiefengineer\Mobilebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal80de0ebd7d076cd9511551113cf7ca55)): ?>
<?php $component = $__componentOriginal80de0ebd7d076cd9511551113cf7ca55; ?>
<?php unset($__componentOriginal80de0ebd7d076cd9511551113cf7ca55); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->role == 'salesmanager'): ?>
                                        <?php if (isset($component)) { $__componentOriginal053406024faa10835e00b9f808d7b06d = $component; } ?>
<?php $component = App\View\Components\User\Salesmanager\Mobilebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.salesmanager.mobilebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Salesmanager\Mobilebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal053406024faa10835e00b9f808d7b06d)): ?>
<?php $component = $__componentOriginal053406024faa10835e00b9f808d7b06d; ?>
<?php unset($__componentOriginal053406024faa10835e00b9f808d7b06d); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->role == 'salesperson'): ?>
                                        <?php if (isset($component)) { $__componentOriginal4d3619f46e32e4c06f624a53784c101e = $component; } ?>
<?php $component = App\View\Components\User\Salesperson\Mobilebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.salesperson.mobilebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Salesperson\Mobilebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d3619f46e32e4c06f624a53784c101e)): ?>
<?php $component = $__componentOriginal4d3619f46e32e4c06f624a53784c101e; ?>
<?php unset($__componentOriginal4d3619f46e32e4c06f624a53784c101e); ?>
<?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <br>
                                </ul>

                             </nav>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Mobile Menu end -->
        
<?php /**PATH C:\xampp\htdocs\erp1\resources\views/layouts/parts/header.blade.php ENDPATH**/ ?>
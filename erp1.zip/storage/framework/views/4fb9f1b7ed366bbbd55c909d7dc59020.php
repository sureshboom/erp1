<div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href=""><img class="main-logo" src="<?php echo e(asset('image/skslogo.png')); ?>" alt="" /></a>
                <strong><a href=""><img src="<?php echo e(asset('image/skslogo.png')); ?>" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a  href="<?php echo e(route('user.dashboard')); ?>">
                                   <span class="educate-icon educate-home icon-wrap"></span>
                                   <span class="mini-click-non">Dashboard</span>
                                </a>
                        </li>
                        <?php if(auth()->guard('user')->check()): ?>
                            <?php if(auth()->user()->role == 'telecaller'): ?>
                                <?php if (isset($component)) { $__componentOriginal1391a88397b96c3631a297681e812260 = $component; } ?>
<?php $component = App\View\Components\User\Telecaller\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.telecaller.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Telecaller\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1391a88397b96c3631a297681e812260)): ?>
<?php $component = $__componentOriginal1391a88397b96c3631a297681e812260; ?>
<?php unset($__componentOriginal1391a88397b96c3631a297681e812260); ?>
<?php endif; ?>
                            <?php endif; ?>
                            <?php if(auth()->user()->role == 'account'): ?>
                                <?php if (isset($component)) { $__componentOriginal743f1870a05a8c4e285140c879677d24 = $component; } ?>
<?php $component = App\View\Components\User\Account\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.account.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Account\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal743f1870a05a8c4e285140c879677d24)): ?>
<?php $component = $__componentOriginal743f1870a05a8c4e285140c879677d24; ?>
<?php unset($__componentOriginal743f1870a05a8c4e285140c879677d24); ?>
<?php endif; ?>
                            <?php endif; ?>
                            <?php if(auth()->user()->role == 'siteengineer'): ?>
                                <?php if (isset($component)) { $__componentOriginal0dd8e6bba6a0176d0e846f646f88a37e = $component; } ?>
<?php $component = App\View\Components\User\Siteengineer\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.siteengineer.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Siteengineer\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0dd8e6bba6a0176d0e846f646f88a37e)): ?>
<?php $component = $__componentOriginal0dd8e6bba6a0176d0e846f646f88a37e; ?>
<?php unset($__componentOriginal0dd8e6bba6a0176d0e846f646f88a37e); ?>
<?php endif; ?>
                            <?php endif; ?>
                            <?php if(auth()->user()->role == 'chiefengineer'): ?>
                                <?php if (isset($component)) { $__componentOriginal3afed18e422fed9ede0d6c0519b1d87c = $component; } ?>
<?php $component = App\View\Components\User\Chiefengineer\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.chiefengineer.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Chiefengineer\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3afed18e422fed9ede0d6c0519b1d87c)): ?>
<?php $component = $__componentOriginal3afed18e422fed9ede0d6c0519b1d87c; ?>
<?php unset($__componentOriginal3afed18e422fed9ede0d6c0519b1d87c); ?>
<?php endif; ?>
                            <?php endif; ?>
                            <?php if(auth()->user()->role == 'salesmanager'): ?>
                                <?php if (isset($component)) { $__componentOriginal28a1ad59e9adc42b2345d9f30bd53a76 = $component; } ?>
<?php $component = App\View\Components\User\Salesmanager\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.salesmanager.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Salesmanager\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28a1ad59e9adc42b2345d9f30bd53a76)): ?>
<?php $component = $__componentOriginal28a1ad59e9adc42b2345d9f30bd53a76; ?>
<?php unset($__componentOriginal28a1ad59e9adc42b2345d9f30bd53a76); ?>
<?php endif; ?>
                            <?php endif; ?>
                            <?php if(auth()->user()->role == 'salesperson'): ?>
                                <?php if (isset($component)) { $__componentOriginalc89d9131b784eab6e22550c1d456cd4f = $component; } ?>
<?php $component = App\View\Components\User\Salesperson\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('user.salesperson.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\User\Salesperson\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc89d9131b784eab6e22550c1d456cd4f)): ?>
<?php $component = $__componentOriginalc89d9131b784eab6e22550c1d456cd4f; ?>
<?php unset($__componentOriginalc89d9131b784eab6e22550c1d456cd4f); ?>
<?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </nav>
            </div>
        </nav>
    </div><?php /**PATH C:\xampp\htdocs\erp1\resources\views/layouts/parts/sidebar.blade.php ENDPATH**/ ?>
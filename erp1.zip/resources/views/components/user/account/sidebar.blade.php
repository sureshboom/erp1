
 <li>
    <a  href="{{ route('account.landcustomer.index')}}">
       <span class="educate-icon educate-professor icon-wrap"></span>
       <span class="mini-click-non">Land Customers</span>
    </a>
</li>
<li>
    <a  href="{{ route('account.materialstatus')}}">
       <span class="educate-icon educate-form icon-wrap"></span>
       <span class="mini-click-non">Material Details</span>
    </a>
</li>
<li>
    <a class="has-arrow" href="#">
       <span class="educate-icon educate-form icon-wrap"></span>
       <span class="mini-click-non">Payments</span>
    </a>
    <ul class="submenu-angle" aria-expanded="true">
        <li><a title="owner" href="{{ route('account.site_payment.index')}}"><span class="mini-sub-pro">Site Payments</span></a></li>
        <li><a title="sites" href="{{ route('account.material_payment.index')}}"><span class="mini-sub-pro">Material Payments</span></a></li>
        <li><a title="sites" href="{{ route('account.land_payment.index')}}"><span class="mini-sub-pro">Land Payments</span></a></li>
    </ul>
</li>
<li>
    <a  href="{{ route('account.expense.index')}}">
       <span class="educate-icon educate-data-table icon-wrap"></span>
       <span class="mini-click-non">Expense</span>
    </a>
</li>
<li>
    <a  href="#">
       <span class="educate-icon educate-event icon-wrap"></span>
       <span class="mini-click-non">Attendance</span>
    </a>
</li>
<li>
    <a  href="#">
       <span class="educate-icon educate-event icon-wrap"></span>
       <span class="mini-click-non">Salary</span>
    </a>
</li>
<li>
    <a class="has-arrow" href="#">
       <span class="educate-icon educate-library icon-wrap"></span>
       <span class="mini-click-non">Reports</span>
    </a>
</li>
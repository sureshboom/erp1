<li>
    <a  href="#">
       <span class="educate-icon educate-data-table icon-wrap"></span>
       <span class="mini-click-non">Site Details</span>
    </a>
</li>
<li>
    <a  href="#">
       <span class="educate-icon educate-professor icon-wrap"></span>
       <span class="mini-click-non">Meshthri</span>
    </a>
</li>

<li>
    <a  href="#">
       <span class="educate-icon educate-interface icon-wrap"></span>
       <span class="mini-click-non">Material Details</span>
    </a>
</li>
<li>
    <a  href="#">
       <span class="educate-icon educate-event icon-wrap"></span>
       <span class="mini-click-non">Workers Salary</span>
    </a>
</li>
<li>
    <a  href="#">
       <span class="educate-icon educate-event icon-wrap"></span>
       <span class="mini-click-non">Work Details</span>
    </a>
</li>
<li>
    <a class="has-arrow" href="#">
       <span class="educate-icon educate-library icon-wrap"></span>
       <span class="mini-click-non">Reports</span>
    </a>
</li>
<li class="active">
    <a  href="#">
       <span class="educate-icon educate-professor icon-wrap"></span>
       <span class="mini-click-non">Supplier</span>
    </a>
 </li>
 <li>
    <a  href="#">
       <span class="educate-icon educate-professor icon-wrap"></span>
       <span class="mini-click-non">Land Customers</span>
    </a>
</li>
<li>
    <a  href="#">
       <span class="educate-icon educate-form icon-wrap"></span>
       <span class="mini-click-non">Material Details</span>
    </a>
</li>
<li>
    <a  href="#">
       <span class="educate-icon educate-data-table icon-wrap"></span>
       <span class="mini-click-non">Income</span>
    </a>
</li>
<li>
    <a  href="#">
       <span class="educate-icon educate-data-table icon-wrap"></span>
       <span class="mini-click-non">Expense</span>
    </a>
</li>
<li>
    <a  href="#">
       <span class="educate-icon educate-event icon-wrap"></span>
       <span class="mini-click-non">Attendance</span>
    </a>
</li>
<li>
    <a  href="#">
       <span class="educate-icon educate-event icon-wrap"></span>
       <span class="mini-click-non">Salary</span>
    </a>
</li>
<li>
    <a class="has-arrow" href="#">
       <span class="educate-icon educate-library icon-wrap"></span>
       <span class="mini-click-non">Reports</span>
    </a>
</li>
    <div class="footer-copyright-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-copy-right">
                        <p>Copyright © 2023. All rights reserved <a href="#.">Macnus</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('layouts.parts.script')
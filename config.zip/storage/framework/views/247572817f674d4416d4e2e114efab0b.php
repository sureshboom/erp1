<li >
    <a  href="<?php echo e(route('telecaller.customer.index')); ?>">
       <span class="educate-icon educate-professor icon-wrap"></span>
       <span class="mini-click-non">Customer</span>
    </a>
</li>
<li >
    <a  href="<?php echo e(route('telecaller.sitevisit.index')); ?>">
       <span class="educate-icon educate-data-table icon-wrap"></span>
       <span class="mini-click-non">Site Visits</span>
    </a>
</li>
<li >
    <a  href="<?php echo e(route('telecaller.todays_work.index')); ?>">
       <span class="educate-icon educate-data-table icon-wrap"></span>
       <span class="mini-click-non">Todays Work</span>
    </a>
</li>
<li>
   <a class="has-arrow" href="#">
       <span class="educate-icon educate-library icon-wrap"></span>
       <span class="mini-click-non">Reports</span>
    </a>
</li>
<?php /**PATH C:\xampp\htdocs\erp\resources\views/components/user/telecaller/sidebar.blade.php ENDPATH**/ ?>
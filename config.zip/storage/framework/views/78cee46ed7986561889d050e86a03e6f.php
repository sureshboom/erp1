<!-- jquery
		============================================ -->
    <script src="<?php echo e(asset('assets/js/vendor/jquery-1.12.4.min.js')); ?>"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <!-- wow JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/jquery-price-slider.js')); ?>"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/jquery.meanmenu.js')); ?>"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <!-- sticky JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/jquery.sticky.js')); ?>"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/jquery.scrollUp.min.js')); ?>"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/scrollbar/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/scrollbar/mCustomScrollbar-active.js')); ?>"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/metisMenu/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/metisMenu/metisMenu-active.js')); ?>"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/sparkline/jquery.sparkline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/sparkline/jquery.charts-sparkline.js')); ?>"></script>
    <!-- calendar JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/calendar/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/calendar/fullcalendar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/calendar/fullcalendar-active.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/data-table/bootstrap-table.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/tableExport.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/data-table-active.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/bootstrap-table-editable.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/bootstrap-editable.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/bootstrap-table-resizable.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/colResizable-1.5.source.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/data-table/bootstrap-table-export.js')); ?>"></script>
    <!--  editable JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/editable/jquery.mockjax.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/mock-active.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/select2.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/bootstrap-datetimepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/bootstrap-editable.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/editable/xediable-active.js')); ?>"></script>


    <!-- maskedinput JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/jquery.maskedinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/masking-active.js')); ?>"></script>
    <!-- datepicker JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/datepicker/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/datepicker/datepicker-active.js')); ?>"></script>
    <!-- form validate JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/form-validation/jquery.form.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/form-validation/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/form-validation/form-active.js')); ?>"></script>
    <!-- dropzone JS
        ============================================ -->
    <script src="<?php echo e(asset('assets/js/dropzone/dropzone.js')); ?>"></script>
    <!-- tab JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/tab.js')); ?>"></script>
    <!-- plugins JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/plugins.js')); ?>"></script>
    <!-- main JS
		============================================ -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <!-- tawk chat JS
		============================================ -->
    <!-- <script src="<?php echo e(asset('assets/js/tawk-chat.js')); ?>"></script> -->

    <script>
    <?php if(Session::has('success')): ?>
    toastr.success("<?php echo e(Session::get('success')); ?>", 'Success!')
    <?php endif; ?>

    <?php if(Session::has('warning')): ?>
    toastr.warning("<?php echo e(Session::get('warning')); ?>", 'Warning!')
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
    toastr.error("<?php echo e(Session::get('error')); ?>", 'Error!')
    <?php endif; ?>

    // toast config
    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": true,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "hideMethod": "fadeOut"
    }

</script><?php /**PATH C:\xampp\htdocs\erp\resources\views/admin/parts/script.blade.php ENDPATH**/ ?>
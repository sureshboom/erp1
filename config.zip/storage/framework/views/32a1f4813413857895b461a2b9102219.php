<li><a href="#">Customer</a></li>
<li><a href="#">Site Visit</a></li>
<li><a data-toggle="collapse" data-target="#Charts" href="#">Reports <span class="admin-project-icon edu-icon edu-down-arrow"></span></a>
    <!-- <ul class="collapse dropdown-header-top">
        <li><a href="index.html">Dashboard v.1</a></li>
        <li><a href="index-1.html">Dashboard v.2</a></li>
        <li><a href="index-3.html">Dashboard v.3</a></li>
        <li><a href="analytics.html">Analytics</a></li>
        <li><a href="widgets.html">Widgets</a></li>
    </ul> -->
</li><?php /**PATH C:\xampp\htdocs\erp\resources\views/components/user/salesperson/mobilebar.blade.php ENDPATH**/ ?>